import numpy as np
import matplotlib.pyplot as plt
omg = np.arange(0,6*np.pi+0.001,0.001)
int_omg = np.array(omg/(2*np.pi),dtype='int')
Xjomg = (np.exp(-omg + 2*np.pi*int_omg) + np.exp(omg - 2*np.pi - 2*np.pi * int_omg))/(1-np.exp(-2*np.pi))
omg1 = np.arange(-6*np.pi,0,0.001)
int_omg1 = np.array(omg1/(2*np.pi),dtype='int')
Xjomg1 = (np.exp(-omg1 - 2*np.pi + 2*np.pi*int_omg1) + np.exp(omg1 - 2*np.pi * int_omg1))/(1-np.exp(-2*np.pi))
omg = np.concatenate((omg1,omg))
Xjomg = np.concatenate((Xjomg1,Xjomg))
plt.plot(omg,Xjomg)
plt.show()
