import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fft,ifft

x = np.loadtxt('data2.txt')
### PART A
xx = np.arange(len(x))
x2 = x[::2]
### PART B
x3 = np.zeros(len(x))
for i in range(len(x3)):
    if not i%2:
        x3[i] = x2[int(i/2)]

x4 = np.zeros(len(x))
for i in range(len(x3)):
    for j in range(int(len(x3)/2)):
        if i==2*j:
            x4[i] += x3[2*j]
        else:
            x4[i] += x3[2*j]*np.sin(np.pi*(i-j*2)/2)/(np.pi*(i-j*2)/2)
plt.stem(xx,x4)
plt.show()

### PART C
y = fft(x)
y1 = np.zeros(len(x))
y1[25:75] = y[25:75]
x5 = ifft(y1)
x5 = x5[::2]

### PART D
x6 = np.zeros(len(x))
for i in range(len(x6)):
    if not i%2:
        x6[i] = x5[int(i/2)]


x7 = np.zeros(len(x))
for i in range(len(x6)):
    for j in range(int(len(x6)/2)):
        if i==2*j:
            x7[i] += x6[2*j]
        else:
            x7[i] += x6[2*j]*np.sin(np.pi*(i-j*2)/2)/(np.pi*(i-j*2)/2)
### PART E

errorb1 = np.sqrt(np.mean((x4 - x)**2))
errorb2 = np.sqrt(np.mean((x4[1::2] - x[1::2])**2))
errorb3 = np.sqrt(np.mean((x4[::2] - x2)**2))

errord1 = np.sqrt(np.mean((x7 - x)**2))
errord2 = np.sqrt(np.mean((x7[1::2] - x[1::2])**2))
errord3 = np.sqrt(np.mean((x7[::2] - x2)**2))

print('All:',errorb1,errord1)
print('Reconstructed:',errorb2,errord2)
print('Non-reconstructed:',errorb3,errord3)
