n = linspace(-50, 50, 101);
% cos(w0*n+theta)
w0 = pi/3;
theta = pi/4;
x = cos(w0*n+theta);
subplot(3, 1, 1);
stem(n, x);
title('cos(w0*n+theta)');
% abs(c) * exp(r * n)
c = 2;
r = 1/10;
x = abs(c) * exp(r * n);
subplot(3, 1, 2);
stem(n, x);
title('abs(c) * exp(r * n)');
% cos(w0*n+theta)*abs(c) .* exp(r * n)
x = cos(w0*n+theta)*abs(c) .* exp(r * n);
subplot(3, 1, 3);
stem(n, x);
title('cos(w0*n+theta)*abs(c) .* exp(r * n)');