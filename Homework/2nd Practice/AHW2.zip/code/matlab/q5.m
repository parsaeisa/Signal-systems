n = linspace(-5, 5, 11);
x = 3 * sin(pi * n) + 3 * abs(cos(7 * n));
y = []
for i = x
    if i > 5
        y = [y 5];
    elseif i < 0
        y = [y 0];
    else
        y = [y i];
    end
end
subplot(2, 1, 1);
stem(n, x);
title('x[n]');
subplot(2, 1, 2);
stem(n, y);
title('y[n]');