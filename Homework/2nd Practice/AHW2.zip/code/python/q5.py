#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

pi = np.pi
n = np.linspace(-5, 5, 11)
x = 3 * np.sin(pi * n) + 3 * np.abs(np.cos(7 * n))
y = []
for i in x:
    if i > 5:
        y.append(5)
    elif i < 0:
        y.append(0)
    else:
        y.append(i)
fig, axs = plt.subplots(2, 1, constrained_layout=True)
axs[0].stem(n, x)
axs[0].set_title('x[n]')
axs[1].stem(n, y)
axs[1].set_title('y[n]')
plt.show()
