#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

pi = np.pi
n = np.linspace(-50, 50, 101)
# cos(w0*n+theta)
w0 = pi/3
theta = pi/4
x = np.cos(w0*n+theta)
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].stem(n, x)
axs[0].set_title('cos(w0*n+theta)')
# abs(c) * exp(r * n)
c = 2
r = 1/10
x = np.abs(c) * np.exp(r * n)
axs[1].stem(n, x)
axs[1].set_title('abs(c) * exp(r * n)')
# cos(w0*n+theta)*abs(c) * exp(r * n)
x = np.cos(w0*n+theta)*np.abs(c) * np.exp(r * n)
axs[2].stem(n, x)
axs[2].set_title('cos(w0*n+theta)*abs(c) * exp(r * n)')
plt.show()
