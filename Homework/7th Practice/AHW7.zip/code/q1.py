#!/usr/bin/env python3
import numpy as np

j = np.complex(0, 1)
pi = np.pi
N = int(input("Enter N: "))
w0 = 2 * pi / N
x = []
for i in range(N):
    x.append(float(input("Enter x[" + str(i) + "]: ")))
a = []
for k in range(N):
    res = 0
    for n in range(N):
        res += (x[n] * np.exp((-1) * j * k * w0 * n))
    res /= N
    a.append(res)
print(a)