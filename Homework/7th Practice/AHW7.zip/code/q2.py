#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

j = np.complex(0, 1)
pi = np.pi
N = int(input("Enter N: "))
x = []
for i in range(N):
    x.append(float(input("Enter x[" + str(i) + "]: ")))
a = []
for k in range(N):
    res = 0
    for n in range(N):
        res += (x[n] * np.exp((-1) * j * k * 2 * pi * n / N))
    a.append(res)

M = list(np.arange(int(N / 2) + 1))
fig, axs = plt.subplots(len(M) + 1, 1)
axs[0].stem(range(N), x, use_line_collection = True)
axs[0].set_title('x[n]')

for m in M:
    xm = []
    for n in range(N):
        res = 0
        for k in range((-1) * m, m + 1):
            res += a[int(k % len(a))] * np.exp(j * k * 2 * pi * n / N)
        res /= (2 * m + 1)
        xm.append(res)
    axs[M.index(m) + 1].stem(range(N), xm, use_line_collection = True)
    axs[M.index(m) + 1].set_title('m = ' + str(m))
plt.show()
