#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

x = [0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0]
n = 10000
y = np.fft.fft(x, n)
# or
# n = 10000
# x = [0 1 2 3 4 5 4 3 2 1 0] + list(np.zeros(n-11))
# y = fft(x)
fig, axs = plt.subplots(4, 1, constrained_layout=True)
axs[0].stem(np.linspace(0, 2 * np.pi, n), y)
axs[0].set_title('x(e^jw)')
axs[1].stem(np.linspace(0, 2 * np.pi, n), np.absolute(y))
axs[1].set_title('|x(e^jw)|')
axs[2].stem(np.linspace(0, 2 * np.pi, n), np.angle(y))
axs[2].set_title('angle(x(e^jw))')
axs[3].stem(range(len(x)), x)
axs[3].set_title('x[n]')
plt.show()
