#!/usr/bin/env python3
import numpy as np

x = [0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0]
N = 11
print(np.fft.fft(x)/N)
