#!/usr/bin/env python3
from scipy.io import wavfile as wav
import numpy as np

pi = np.pi
j = np.complex(0, 1)
e = np.e

rate, data = wav.read('mic.wav')
if type(data[0]) == list: # changing stereo sound to mono
    data = data[:,0]
f = np.fft.fft(data)
m = np.absolute(f)
p = np.angle(f)

# mines phase
mp = -1 * p
mf = m * (e ** (j * mp))
md = np.fft.ifft(mf)
wav.write("mt.wav", rate, md.astype(data.dtype))

#zero phase
mp = 0 * p
mf = m * (e ** (j * mp))
md = np.fft.ifft(mf)
wav.write("zt.wav", rate, md.astype(data.dtype))

#phase + pi/2
mp = np.copy(p)
for i in range(len(p)):
    mp[i] += i * (pi / 2)
mf = m * (e ** (j * mp))
md = np.fft.ifft(mf)
wav.write("p2pt.wav", rate, md.astype(data.dtype))

#phase + pi
mp = np.copy(p)
for i in range(len(p)):
    mp[i] += i * (pi - 0.1)
mf = m * (e ** (j * mp))
md = np.fft.ifft(mf)
wav.write("ppt.wav", rate, md.astype(data.dtype))

#phase - pi / 2
mp = np.copy(p)
for i in range(len(p)):
    mp[i] -= i * (pi / 2)
#pdb.set_trace()
mf = m * (e ** (j * mp))
md = np.fft.ifft(mf)
wav.write("p2mt.wav", rate, md.astype(data.dtype))

# double abs
mf = 2 * m * (e ** (j * p))
md = np.fft.ifft(mf)
wav.write("da.wav", rate, md.astype(data.dtype))

# ten *  abs
mf = 10 * m * (e ** (j * p))
md = np.fft.ifft(mf)
wav.write("ten_a.wav", rate, md.astype(data.dtype))

# abs = miangin
mi = sum(m) / len(m)
mf =  mi * (e ** (j * p))
md = np.fft.ifft(mf)
wav.write("mia.wav", rate, md.astype(data.dtype))

# subs
rate1, data1 = wav.read('trac.wav')
if type(data1[0]) == list: # changing stereo sound to mono
    data1 = data1[:,0]
f1 = np.fft.fft(data1)
m1 = np.absolute(f1)
p1 = np.angle(f1)
# make same shape
if len(m) < len(p1):
    mt = m * (e ** (j * p1[:len(m)]))
else:
    mt = m[:len(p1)] * (e ** (j * p1))
imt = np.fft.ifft(mt)
wav.write("a_m_p_t.wav", rate, imt.astype(data.dtype)) # abs from mic and phase from trac
# make same shape
if len(m1) < len(p):
    tm = m1 * (e ** (j * p[:len(m1)]))
else:
    tm = m1[:len(p)] * (e ** (j * p))
itm = np.fft.ifft(tm)
wav.write("a_t_p_m.wav", rate, itm.astype(data.dtype)) # abs from trac and phase from mic




