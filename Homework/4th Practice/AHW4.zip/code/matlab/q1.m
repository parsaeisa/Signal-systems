function q1()
nh = linspace(1, 13, 13);
h = u(nh - 1) - u(nh - 14);
% a
nx1 = linspace(1, 6, 6);
x1 = u(nx1 - 1) - 2 * u(nx1 - 4) + u(nx1 - 7);
y1 = conv(x1, h, 'full');
ny1 = linspace(2, 19, 18);

nplt = linspace(0, 14, 15);
x1plt = u(nplt - 1) - 2 * u(nplt - 4) + u(nplt - 7);
hplt = u(nplt - 1) - u(nplt - 14);
figure(1);
subplot(3, 1, 1);
stem(nplt, x1plt);
title('x1[n]');
subplot(3, 1, 2);
stem(nplt, hplt);
title('h[n]');
subplot(3, 1, 3);
stem(ny1, y1);
title('y1[n]');
% b
nx2 = linspace(1, 11, 11);
x2 = (u(nx2) - u(nx2 - 12)) .* sin((pi / 6) * nx2);
y2 = conv(x2, h, 'full');
ny2 = linspace(2, 24, 23);

x2plt = (u(nplt) - u(nplt - 12)) .* sin((pi / 6) * nplt);
figure(2);
subplot(3, 1, 1);
stem(nplt, x2plt);
title('x2[n]');
subplot(3, 1, 2);
stem(nplt, hplt);
title('h[n]');
subplot(3, 1, 3);
stem(ny2, y2);
title('y2[n]');
end

function y = u(n)
nu = n;
nu(nu == 0) = 1;
y = heaviside(nu);
end