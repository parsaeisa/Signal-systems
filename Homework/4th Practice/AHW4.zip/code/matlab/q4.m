[x, Fs] = audioread('speech.wav');
x = x(:,1); % changing stereo sound to mono

N = Fs / 2;
h = zeros(1, (3 * N) + 1);
h(1) = 1;
h(N + 1) = 1 / 2;
h((2 * N) + 1) = 1 / 4;
h((3 * N) + 1) = 1 / 8;
y = conv(x, h);
audiowrite('res.wav', y, Fs);

% Be careful that saved file is in bin directory in matlab path where installed.