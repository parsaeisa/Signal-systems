#!/usr/bin/env python3
from scipy.io import wavfile as wav
import numpy as np


rate, data = wav.read('speech.wav')
if type(data[0]) == list: # changing stereo sound to mono
    data = data[:,0]

N = int(rate / 2)
h = np.zeros((3 * N) + 1)
h[0] = 1
h[N] = 1 / 2
h[2 * N] = 1 / 4
h[3 * N] = 1 / 8
y = np.convolve(data, h)
wav.write("res.wav", rate, y.astype(data.dtype))