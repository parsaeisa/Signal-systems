#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

def u(n):
	u = np.heaviside(n, 1)
	return u


nh = np.linspace(1, 13, 13)
h = u(nh - 1) - u(nh - 14)
# a
nx1 = np.linspace(1, 6, 6)
x1 = u(nx1 - 1) - 2 * u(nx1 - 4) + u(nx1 - 7)
y1 = np.convolve(x1, h, mode = 'full')
ny1 = np.linspace(2, 19, 18)

nplt = np.linspace(0, 14, 15)
x1plt = u(nplt - 1) - 2 * u(nplt - 4) + u(nplt - 7)
hplt = u(nplt - 1) - u(nplt - 14)
fig, axs = plt.subplots(3, 1, constrained_layout = True)
axs[0].stem(nplt, x1plt, use_line_collection = True)
axs[0].set_title('x1[n]')
axs[1].stem(nplt, hplt, use_line_collection = True)
axs[1].set_title('h[n]')
axs[2].stem(ny1, y1, use_line_collection = True)
axs[2].set_title('y1[n]')
axs[2].set_xticks(ny1)
plt.show()
# b
nx2 = np.linspace(1, 11, 11)
x2 = (u(nx2) - u(nx2 - 12)) * np.sin((np.pi / 6) * nx2)
y2 = np.convolve(x2, h, mode = 'full')
ny2 = np.linspace(2, 24, 23)

x2plt = (u(nplt) - u(nplt - 12)) * np.sin((np.pi / 6) * nplt)
fig, axs = plt.subplots(3, 1, constrained_layout = True)
axs[0].stem(nplt, x2plt, use_line_collection = True)
axs[0].set_title('x2[n]')
axs[1].stem(nplt, hplt, use_line_collection = True)
axs[1].set_title('h[n]')
axs[2].stem(ny2, y2, use_line_collection = True)
axs[2].set_title('y2[n]')
plt.show()