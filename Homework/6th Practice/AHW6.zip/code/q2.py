import numpy as np
import matplotlib.pyplot as plt


def calculate_fourier(k):
    if k == 0:
        return 0
    return (-np.exp((complex(0, 1) * np.pi * k / 3)) \
            + np.exp((complex(0, 1) * np.pi * k * 2 / 3)) \
            + np.exp(-(complex(0, 1) * np.pi * k * 2 / 3)) \
            - np.exp(-(complex(0, 1) * np.pi * k / 3))) / (complex(0, 1) * 2 * k * np.pi)


def estimate_signal(c, t_range):
    result = 0
    xt = []
    T = 6
    for t in t_range:
        result = 0
        for k in range(0, len(c)):
            result += c[k] * np.exp(complex(0, 1) * (k - (len(c) - 1) / 2) * t * 2 * np.pi / T)
        xt.append(result)
    return xt


def main_signal_generator(t_range):
    x = []
    for i in t_range:
        if i >= -2 and i <= -1:
            x.append(1)
        elif i >= 1 and i <= 2:
            x.append(-1)
        else:
            x.append(0)
    return x


if __name__ == '__main__':
    M = [1, 2, 5, 10, 50]
    t_range = np.linspace(-3, 3, 600)
    fig, axs = plt.subplots(6, 1, constrained_layout=True)
    x = main_signal_generator(t_range)
    axs[0].plot(t_range, x)
    axs[0].set_title('x(t)')
    for m in M:
        c = []
        K = range(-m, m + 1)
        for k in K:
            c.append(calculate_fourier(k))
        xt = estimate_signal(c, t_range)
        axs[M.index(m) + 1].plot(t_range, xt)
        axs[M.index(m) + 1].set_title('m = ' + str(m))
    plt.show()
